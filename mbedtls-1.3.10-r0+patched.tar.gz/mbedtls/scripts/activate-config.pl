#!/usr/bin/perl

# DEPRECATED!
#
# activate a pre-defined configuration

print "This script is deprecated!\n";
print "See configs/README.txt regarding alternative config.h usage\n";
exit 1;
